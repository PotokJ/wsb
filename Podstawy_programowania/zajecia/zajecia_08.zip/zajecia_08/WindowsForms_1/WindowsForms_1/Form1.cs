﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /*Zad do domu
         * 
         * kalkulator bardzo prosty
         * 3 pola tekstowe
         * przycisk
         * na 1 polu liczba, na drugim liczba na 3 polu "Wynik dodawania: "
         */

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = textBox1.Text;
            textBox1.Text = "";
        }
    }
}
