﻿using System;

namespace wskazniki_1
{
    class Program
    {
        unsafe static void Main(string[] args) //trzeba dodać unsafe przed static void Main, żeby użyc wskaźników
        {
            char* x; //* = wskaźnik
            char letter = 'x';
            x = &letter; //przypisanie ADRESU zmiennej letter (x przechowuje adres zmiennej)
            letter = 'a';

            Console.WriteLine("Znak: {0}", letter); //x, po zmianie a
            Console.WriteLine("Znak: {0}", *x); //x, potem a, odwołanie się do wskaźnika w pamięci, trzeba dać * przed x
            Console.WriteLine("Adres pamięci zmiennej: {0}", (int)x);//trzeba przekonwertować char na int ("(int)x"), wyświetli adres
            //Console.WriteLine("Adres pamięci zmiennej szesnastkowo: {0:x}", (int)x); //wyświetlić szestnastkowo {0:x} (x - oznaczenie heksadecymalnego)

            int test = 123;
            Console.WriteLine(Convert.ToString(test, 16));

            double number;
            double* numberAddress;

            number = 10;
            numberAddress = &number;

            Console.WriteLine("\nLiczba wynosi: {0}", number);
            Console.WriteLine("Liczba wynosi: {0}", numberAddress->ToString()); //"->" = operator wskaźnika do składowej, to samo co *numberAddress
            Console.WriteLine("Adres zmiennej wynosi: {0}", (int)numberAddress);

            Console.ReadKey();
        }
    }
}
