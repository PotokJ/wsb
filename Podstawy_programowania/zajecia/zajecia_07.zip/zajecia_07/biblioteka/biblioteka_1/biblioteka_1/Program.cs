﻿using System;
using biblioteka_dll;

namespace biblioteka_1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Widok->eksplorator rozwiązań->odwołania->dodaj odwołanie->przeglądaj->biblioteka_dll.dll->using biblioteka_dll
            Class1 x = new Class1(); //Class1 pochodzi z biblioteka_dll

            Console.WriteLine(x.Add(3, 5));

            Console.ReadKey();
        }
    }
}
