﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wskazniki_4
{
    class Program
    {
        struct Test
        {
            public int n;
        }

        unsafe static void Main(string[] args)
        {
            Test x = new Test();
            Test* p = &x;
            p->n = 20;// przypisywanie wartości do wskaźnika
            //lub
            //(*p).n = 20;

            Console.WriteLine(x.n); //20
            Console.ReadKey();
        }
    }
}
