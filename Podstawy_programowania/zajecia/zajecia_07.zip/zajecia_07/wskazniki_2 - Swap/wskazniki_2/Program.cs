﻿using System;

namespace wskazniki_2
{
    class Program
    {
        unsafe static void Swap(int* a, int* b)
        {
            int pomocnicza = *a;
            *a = *b;
            *b = pomocnicza;
          
        }

        unsafe static void Main(string[] args)
        {
            //1 sposób zamieniania:
            int x = 2;
            int y = 5;

            Console.WriteLine("Wartości przed zamianą: x = {0}, y = {1}", x, y); //x=2 y=5
            Swap(&x, &y); //adresy
            Console.WriteLine("Wartości po zamianie: x = {0}, y = {1}", x, y);//x=5 y=2
            
            //2 sposób zamienienia:
            int a = 100;
            int b = 200;

            int* a1 = &a;
            int* b1 = &b;
            Console.WriteLine("\nWartości przed zamianą: a = {0}, b = {1}", a, b);
            Swap(a1, b1);
            Console.WriteLine("Wartości po zamianie: a = {0}, b = {1}", a, b);

            Console.ReadKey();
        }
    }
}
