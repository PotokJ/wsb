﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double firstNumber;
        double secondNumber;
        double wynik;

        private void button_Click(object sender, EventArgs e)
        {

            if (result.Text == "0")
                result.Clear();
            
            //sender - jaki obiekt jest nadawcą komunikatu
            Button b = (Button)sender;
            result.Text += b.Text;
        }

        private void button24_Click(object sender, EventArgs e)
        {
            //CE
            result.Text = "0";
        }

        private void operator_click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            string operation = b.Text;

            switch (operation)
            {
                case "+":
                    firstNumber = Convert.ToDouble(result.Text);
                    result.Text = "0";
                    break;
                
                case "-":
                    result.Text += b.Text;
                    break;
                
                case "*":
                    break;
                
                case "/":
                    break;

                case "=":
                    secondNumber = Convert.ToDouble(result.Text);
                    //zmienić zey nie było tylko dodawanie tylko zależnie od wyboru działania
                    wynik = firstNumber + secondNumber;
                    result.Text = "0";
                    result.Text = Convert.ToString(wynik);
                    break;
            }
        }
    }
}
