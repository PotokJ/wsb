﻿namespace pole_obwod_kwadratu
{
    partial class Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblBok = new System.Windows.Forms.Label();
            this.lblObwod = new System.Windows.Forms.Label();
            this.lblPole = new System.Windows.Forms.Label();
            this.lblKomunikat = new System.Windows.Forms.Label();
            this.txtBok = new System.Windows.Forms.TextBox();
            this.txtObwod = new System.Windows.Forms.TextBox();
            this.txtPole = new System.Windows.Forms.TextBox();
            this.btnWyczysc = new System.Windows.Forms.Button();
            this.btnZamknij = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.SuspendLayout();
            // 
            // lblBok
            // 
            this.lblBok.AutoSize = true;
            this.lblBok.Location = new System.Drawing.Point(43, 42);
            this.lblBok.Name = "lblBok";
            this.lblBok.Size = new System.Drawing.Size(26, 13);
            this.lblBok.TabIndex = 0;
            this.lblBok.Text = "Bok";
            // 
            // lblObwod
            // 
            this.lblObwod.AutoSize = true;
            this.lblObwod.Location = new System.Drawing.Point(28, 77);
            this.lblObwod.Name = "lblObwod";
            this.lblObwod.Size = new System.Drawing.Size(41, 13);
            this.lblObwod.TabIndex = 1;
            this.lblObwod.Text = "Obwód";
            // 
            // lblPole
            // 
            this.lblPole.AutoSize = true;
            this.lblPole.Location = new System.Drawing.Point(41, 124);
            this.lblPole.Name = "lblPole";
            this.lblPole.Size = new System.Drawing.Size(28, 13);
            this.lblPole.TabIndex = 2;
            this.lblPole.Text = "Pole";
            // 
            // lblKomunikat
            // 
            this.lblKomunikat.AutoSize = true;
            this.lblKomunikat.ForeColor = System.Drawing.Color.Red;
            this.lblKomunikat.Location = new System.Drawing.Point(196, 37);
            this.lblKomunikat.Name = "lblKomunikat";
            this.lblKomunikat.Size = new System.Drawing.Size(0, 13);
            this.lblKomunikat.TabIndex = 3;
            // 
            // txtBok
            // 
            this.txtBok.Location = new System.Drawing.Point(84, 35);
            this.txtBok.Name = "txtBok";
            this.txtBok.Size = new System.Drawing.Size(100, 20);
            this.txtBok.TabIndex = 4;
            this.txtBok.TextChanged += new System.EventHandler(this.txtBok_TextChanged);
            // 
            // txtObwod
            // 
            this.txtObwod.Enabled = false;
            this.txtObwod.Location = new System.Drawing.Point(84, 74);
            this.txtObwod.Name = "txtObwod";
            this.txtObwod.Size = new System.Drawing.Size(100, 20);
            this.txtObwod.TabIndex = 5;
            // 
            // txtPole
            // 
            this.txtPole.Enabled = false;
            this.txtPole.Location = new System.Drawing.Point(84, 117);
            this.txtPole.Name = "txtPole";
            this.txtPole.Size = new System.Drawing.Size(100, 20);
            this.txtPole.TabIndex = 6;
            // 
            // btnWyczysc
            // 
            this.btnWyczysc.Location = new System.Drawing.Point(52, 159);
            this.btnWyczysc.Name = "btnWyczysc";
            this.btnWyczysc.Size = new System.Drawing.Size(75, 23);
            this.btnWyczysc.TabIndex = 7;
            this.btnWyczysc.Text = "Wyczyść";
            this.btnWyczysc.UseVisualStyleBackColor = true;
            this.btnWyczysc.Click += new System.EventHandler(this.btnWyczysc_Click);
            // 
            // btnZamknij
            // 
            this.btnZamknij.Location = new System.Drawing.Point(137, 159);
            this.btnZamknij.Name = "btnZamknij";
            this.btnZamknij.Size = new System.Drawing.Size(75, 23);
            this.btnZamknij.TabIndex = 8;
            this.btnZamknij.Text = "Zamknij";
            this.btnZamknij.UseVisualStyleBackColor = true;
            this.btnZamknij.Click += new System.EventHandler(this.btnZamknij_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 215);
            this.Controls.Add(this.btnZamknij);
            this.Controls.Add(this.btnWyczysc);
            this.Controls.Add(this.txtPole);
            this.Controls.Add(this.txtObwod);
            this.Controls.Add(this.txtBok);
            this.Controls.Add(this.lblKomunikat);
            this.Controls.Add(this.lblPole);
            this.Controls.Add(this.lblObwod);
            this.Controls.Add(this.lblBok);
            this.Name = "Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form";
            this.Load += new System.EventHandler(this.Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBok;
        private System.Windows.Forms.Label lblObwod;
        private System.Windows.Forms.Label lblPole;
        private System.Windows.Forms.Label lblKomunikat;
        private System.Windows.Forms.TextBox txtBok;
        private System.Windows.Forms.TextBox txtObwod;
        private System.Windows.Forms.TextBox txtPole;
        private System.Windows.Forms.Button btnWyczysc;
        private System.Windows.Forms.Button btnZamknij;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
    }
}

