﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pole_obwod_kwadratu
{
    public partial class Form : System.Windows.Forms.Form
    {
        public Form()
        {
            InitializeComponent();
        }

        private void Form_Load(object sender, EventArgs e)
        {

        }

        private void txtBok_TextChanged(object sender, EventArgs e)
        {
            double x;
            if (double.TryParse(txtBok.Text, out x) && (x > 0))
            {
                lblKomunikat.Text = "";
                txtObwod.Text = (x * 4).ToString();
                txtPole.Text = (x * x).ToString();
            }
            else
            {
                lblKomunikat.Text = "Wpisz liczbę dodatnią";
                txtObwod.Text = "";
                txtPole.Text = "";
            }
        }

        private void btnWyczysc_Click(object sender, EventArgs e)
        {
            txtBok.Text = "";
            lblKomunikat.Text = "Wpisz wymiar boku";
            txtBok.Focus();
        }

        private void btnZamknij_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
