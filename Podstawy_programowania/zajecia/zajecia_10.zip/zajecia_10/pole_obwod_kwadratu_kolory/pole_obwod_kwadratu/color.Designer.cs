﻿namespace pole_obwod_kwadratu
{
    partial class color
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnZamknijColor = new System.Windows.Forms.Button();
            this.btnColorCloseApp = new System.Windows.Forms.Button();
            this.lblColorBok = new System.Windows.Forms.Label();
            this.txtColorBok = new System.Windows.Forms.TextBox();
            this.txtColorPokaz = new System.Windows.Forms.Button();
            this.panelColor = new System.Windows.Forms.Panel();
            this.lblKom = new System.Windows.Forms.Label();
            this.btnKolor = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnZamknijColor
            // 
            this.btnZamknijColor.Location = new System.Drawing.Point(113, 309);
            this.btnZamknijColor.Name = "btnZamknijColor";
            this.btnZamknijColor.Size = new System.Drawing.Size(75, 23);
            this.btnZamknijColor.TabIndex = 0;
            this.btnZamknijColor.Text = "Zamknij";
            this.btnZamknijColor.UseVisualStyleBackColor = true;
            this.btnZamknijColor.Click += new System.EventHandler(this.btnZamknijColor_Click);
            // 
            // btnColorCloseApp
            // 
            this.btnColorCloseApp.Location = new System.Drawing.Point(209, 309);
            this.btnColorCloseApp.Name = "btnColorCloseApp";
            this.btnColorCloseApp.Size = new System.Drawing.Size(119, 23);
            this.btnColorCloseApp.TabIndex = 1;
            this.btnColorCloseApp.Text = "Zamknij program";
            this.btnColorCloseApp.UseVisualStyleBackColor = true;
            this.btnColorCloseApp.Click += new System.EventHandler(this.btnColorCloseApp_Click);
            // 
            // lblColorBok
            // 
            this.lblColorBok.AutoSize = true;
            this.lblColorBok.Location = new System.Drawing.Point(24, 103);
            this.lblColorBok.Name = "lblColorBok";
            this.lblColorBok.Size = new System.Drawing.Size(26, 13);
            this.lblColorBok.TabIndex = 2;
            this.lblColorBok.Text = "Bok";
            // 
            // txtColorBok
            // 
            this.txtColorBok.Location = new System.Drawing.Point(53, 100);
            this.txtColorBok.Name = "txtColorBok";
            this.txtColorBok.Size = new System.Drawing.Size(100, 20);
            this.txtColorBok.TabIndex = 3;
            // 
            // txtColorPokaz
            // 
            this.txtColorPokaz.Location = new System.Drawing.Point(53, 131);
            this.txtColorPokaz.Name = "txtColorPokaz";
            this.txtColorPokaz.Size = new System.Drawing.Size(100, 23);
            this.txtColorPokaz.TabIndex = 4;
            this.txtColorPokaz.Text = "Pokaż";
            this.txtColorPokaz.UseVisualStyleBackColor = true;
            this.txtColorPokaz.Click += new System.EventHandler(this.txtColorPokaz_Click);
            // 
            // panelColor
            // 
            this.panelColor.BackColor = System.Drawing.Color.Black;
            this.panelColor.Location = new System.Drawing.Point(180, 37);
            this.panelColor.Name = "panelColor";
            this.panelColor.Size = new System.Drawing.Size(0, 0);
            this.panelColor.TabIndex = 5;
            // 
            // lblKom
            // 
            this.lblKom.AutoSize = true;
            this.lblKom.ForeColor = System.Drawing.Color.Red;
            this.lblKom.Location = new System.Drawing.Point(50, 79);
            this.lblKom.Name = "lblKom";
            this.lblKom.Size = new System.Drawing.Size(119, 13);
            this.lblKom.TabIndex = 6;
            this.lblKom.Text = "Podaj prawidłowe dane";
            this.lblKom.Visible = false;
            // 
            // btnKolor
            // 
            this.btnKolor.Location = new System.Drawing.Point(53, 161);
            this.btnKolor.Name = "btnKolor";
            this.btnKolor.Size = new System.Drawing.Size(100, 23);
            this.btnKolor.TabIndex = 7;
            this.btnKolor.Text = "Zmiana koloru";
            this.btnKolor.UseVisualStyleBackColor = true;
            this.btnKolor.Click += new System.EventHandler(this.btnKolor_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(457, 24);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.closeToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
            // 
            // color
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(457, 344);
            this.Controls.Add(this.btnKolor);
            this.Controls.Add(this.lblKom);
            this.Controls.Add(this.panelColor);
            this.Controls.Add(this.txtColorPokaz);
            this.Controls.Add(this.txtColorBok);
            this.Controls.Add(this.lblColorBok);
            this.Controls.Add(this.btnColorCloseApp);
            this.Controls.Add(this.btnZamknijColor);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "color";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "color";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnZamknijColor;
        private System.Windows.Forms.Button btnColorCloseApp;
        private System.Windows.Forms.Label lblColorBok;
        private System.Windows.Forms.TextBox txtColorBok;
        private System.Windows.Forms.Button txtColorPokaz;
        private System.Windows.Forms.Panel panelColor;
        private System.Windows.Forms.Label lblKom;
        private System.Windows.Forms.Button btnKolor;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
    }
}