﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pole_obwod_kwadratu
{
    public partial class color : Form
    {
        public color()
        {
            InitializeComponent();
        }

        private void btnZamknijColor_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnColorCloseApp_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtColorPokaz_Click(object sender, EventArgs e)
        {
            int x;
            if (int.TryParse(txtColorBok.Text, out x) && x > 0 && x <= 250)
            {
                panelColor.Height = x;
                panelColor.Width = x;
                lblKom.Visible = false;
            }
            else
            {
                lblKom.Visible = true;
            }
        }

        private void btnKolor_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            panelColor.BackColor = colorDialog1.Color;
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            draw d = new draw();
            d.ShowDialog();
        }
    }
}
