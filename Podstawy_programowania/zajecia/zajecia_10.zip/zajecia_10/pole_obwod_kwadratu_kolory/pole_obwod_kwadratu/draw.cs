﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pole_obwod_kwadratu
{
    public partial class draw : Form
    {
        public draw()
        {
            InitializeComponent();
        }

        private void draw_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
