﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace funkcje2
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
             * Napisz funkcje, która wyświetli czy liczba jest parzysta/nieparzysta
             * Funkcja zwraca string (Liczba parzysta / Liczba nieparzysta)
             */

            int a = 10;
            int b = 9;
            Console.WriteLine(checkEven(a));
            Console.WriteLine(checkEven(b));

            /*
             * Napisz funkcje, która wyświetli sumę cyfr w liczbie
             */

            Console.WriteLine(sumaCyfr(123));

            Console.ReadKey();
        }

        static string checkEven(int a)
        {
            if (a % 2 == 0)
            {
                return "Liczba parzysta";
            }
            else
            {
                return "Liczba nieparzysta";
            }                 
        }

        static int sumaCyfr(int x)
        {
            int sum = 0;

            do
            {
                sum = sum + x % 10; //ostatnia cyfra w liczbie (123 % 10 = 3) -> (12,3 % 10 = 2) itd.
                x /= 10; //dzieli przez 10 więc ostatnia cyfra jest następna (123 / 10 = 12,3)
            } while (x != 0);

            return sum;
        }
    }
}
