﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace funkcje4
{
    class Program
    {
        static void Main(string[] args)
        {

            int a;
            increment(out a); //z out nie potrzebuje wartości początkowej (a)
            Console.WriteLine("Wartość zmiennej a po wywołaniu funkcji: {0}", a);

            Console.ReadKey();

        }

        static void increment(out int x)
        {
            x = 1; //z out tu deklarujemy wartość początkową
            x += 10;
            Console.WriteLine("Zmienna x wewnątrz funkcji: {0}", x);
        }
    }
}
