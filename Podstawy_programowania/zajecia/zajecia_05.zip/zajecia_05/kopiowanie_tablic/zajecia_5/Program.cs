﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zajecia_5
{
    class Program
    {
        static void Main(string[] args)
        {

            //typ wartościowy
            int a = 10;
            int b = a;

            a--;
            b++;

            Console.WriteLine("Zmienna a: {0}", a); //9
            Console.WriteLine("Zmienna b: {0}", b); //11


            //typ referencyjny
            int[] tabA = { 2, 2, 2 };
            int[] tabB = tabA;

            tabA[2] = 10;
            tabB[0] = 8;

            Console.WriteLine("Wyświetlenie tablicy A: ");
            foreach (var item in tabA)
            {
                Console.Write("{0} ", item);

            }

            Console.WriteLine("\nWyświetlenie tablicy B: ");
            foreach (var item in tabB)
            {
                Console.Write("{0} ", item);

            }
            Console.WriteLine();

            //kopiowanie tablic
            int[] tab = { 1, 2, 3, 4, 5 };
            int[] tabCopy = new int[5];

            foreach (int item in tabCopy)
            {
                Console.Write("{0} ", item);
            }
            Console.WriteLine();


            //kopiowanie tablicy 1)
            tab.CopyTo(tabCopy, 0);
            
            foreach (int item in tabCopy)
            {
                Console.Write("{0} ", item);
            }
            Console.WriteLine();


            //2 sposób kopiowanie tablicy
            Array.Copy(tab, tabCopy, tab.Length);
            
            foreach (int item in tabCopy)
            {
                Console.Write("{0} ", item);
            }

            Console.ReadKey();

        }
    }
}
