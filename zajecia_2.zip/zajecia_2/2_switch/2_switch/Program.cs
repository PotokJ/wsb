﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2_switch
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1 - Pole kwadratu\n2 - Pole koła");
            Console.Write("\nPodaj wartość: ");
            string x, bokKwadratu, promien;
            double bokKwadratu1, promien1;
            x = Console.ReadLine();

            switch (x)
            {
                case "1":                  
                        Console.Clear();
                        Console.WriteLine("Pole kwadratu\n");
                        Console.Write("Podaj bok kwadratu: ");
                        bokKwadratu = Console.ReadLine();
                        if (double.TryParse(bokKwadratu, out bokKwadratu1)) //sprawdzanie czy podany bok jest podany poprawnie
                        {
                            double poleKwadratu = bokKwadratu1 * bokKwadratu1;
                            Console.Write("Pole kwadratu wynosi: {0:##.##}", poleKwadratu); //{0:##.##} formatowanie po przecinku
                        }
                        else
                        {
                            Console.WriteLine("Podałeś błędne dane.");
                        }
                        break;
                    
                case "2":      
                        Console.Clear();
                        Console.WriteLine("Pole koła\n");
                        Console.Write("Podaj promień koła: ");
                        promien = Console.ReadLine();
                        if (double.TryParse(promien, out promien1))
                        {
                            double poleKola = Math.PI * promien1 * promien1;
                            Console.Write("Pole koła wynosi: {0:##.##}", poleKola);

                        }
                        else
                        {
                            Console.WriteLine("Podałeś błędne dane.");
                        }
                        break;
                    
                default: //gdy zostały wprowadzone inne dane niż podane w case"" trafiasz tutaj
                    
                        Console.WriteLine("Podałeś błędne dane.");
                    break;
                    
            }

            Console.ReadKey();


        }
    }
}
