﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2_instrukcje_warunkowe
{
    class Program
    {
        static void Main(string[] args)
        {



            
            Console.Write("Podaj długość podstawy trójkąta: ");
            string podstawa = Console.ReadLine();
            double podstawa1, wysokosc1;

            Console.Write("Podaj wysokość trójkąta: ");
            string wysokosc = Console.ReadLine();

            if (double.TryParse(podstawa, out podstawa1) == true && double.TryParse(wysokosc, out wysokosc1))
            {
                double wynik = (podstawa1 * wysokosc1) * 0.5;
                Console.WriteLine("\nDługość podstawy: {0}, wysokość {1}", podstawa1, wysokosc1);
                Console.Write("Pole trójkąta wynosi: {0}", wynik);
            }
            else
            {
                Console.WriteLine("Error! Błędne dane.");
            }
            *





            Console.ReadKey();

        }
    }
}
