﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2_interacje_for
{
    class Program
    {
        static void Main(string[] args)
        {
            /*for(inicjalizacja; warunek; inkrementacja)
             * { 
             * int = i = 0; i < 10; i++LUBi--
             * }
            */

            //wyświetl liczby z przedziału <1;3> 
            /*for (int i = 1; i <= 3; i++) //i - iteracja
            {
                //Console.WriteLine(i);
                Console.Write("{0} ", i);
            }
            */



            //wyświetl liczby parzyste z przedziału <5;20> w porządku malejącym
            /*for (int i = 20; i >= 5; i--)
            {
                if (i % 2 == 0) //i % 2 == 0, reszta z dzielenia i przez 2 = 0
                    Console.Write("{0} ", i);
            }
            */



            /*
             * Wyświetl na ekranie:
             * 
             * *
             * **
             * ***
             * ****
             * *****
             * 
             * Wysokość choinki użytkownik podaje z klawiatry
             */


            Console.WriteLine("Podaj wysokość choinki: ");
            string ile;
            int ile1;
            ile = Console.ReadLine();
            if (int.TryParse(ile, out ile1))

                for (int i = 1; i <= ile1; i++) //wyświetlenie wierszy
            {
                for (int j=0; j<i ;j++) //ilość gwiazdek
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            
            }
            Console.ReadKey();
        }
    }
}
